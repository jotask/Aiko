#include "mesh_component.h"

#include "constants.h"
#include "models/game_object.h"
#include "systems/render_system.h"
#include "models/mesh_factory.h"

namespace aiko
{

    MeshComponent::MeshComponent()
        : Component("Mesh")
    {

    }

    void MeshComponent::init()
    {

        m_material.m_shader.load("model.vs", "model.fs");
        AIKO_ASSERT(m_material.m_shader.isValid(), "Shader is invalid");
        const MeshAsset meshData = mesh::factory::generateCube();
    }

    void MeshComponent::load(const char* filename)
    {
        AIKO_NOT_IMPLEMENTED;
        //m_mesh.load(filename);
        //m_mesh.refresh();
    }

    void MeshComponent::refresh()
    {

    }

}
