#pragma once

#include "models/component.h"
#include "models/material.h"

namespace aiko
{

    class MeshComponent : public Component
    {
    public:

        MeshComponent();
        virtual ~MeshComponent() = default;

        virtual void init() override;

        void load(const char*);
        void refresh();

        const AssetId& getMeshId() const { return m_meshId; };
        MaterialAsset& getMaterial() { return m_material; }
        const MaterialAsset& getMaterial() const { return m_material; }

        AssetId         m_meshId;
        MaterialAsset   m_material;
    };

}