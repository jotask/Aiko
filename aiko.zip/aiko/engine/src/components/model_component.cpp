#include "model_component.h"

#include "constants.h"
#include "models/game_object.h"
#include "systems/render_system.h"

namespace aiko
{

    ModelComponent::ModelComponent()
        : Component("Model")
    {

    }

    void ModelComponent::load(string filename)
    {
        AIKO_NOT_IMPLEMENTED;
        // m_model.upload(filename.c_str());
    }

}
