#pragma once

#include <string>

namespace aiko
{
    namespace global
    {

        inline constexpr bool GPU_LOGGING = true;

        inline const std::string GLOBAL_PATH = "/home/jose/Projects/Aiko/";
        inline const std::string GLOBAL_ASSET_PATH = "/home/jose/Projects/Aiko/assets/";

        inline std::string getAssetPath(const char* subpath)
        {
            std::string buffer;
            buffer.clear();
            buffer += GLOBAL_ASSET_PATH;
            buffer += subpath;
            return buffer;

        }

    }
}
