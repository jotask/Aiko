#pragma once

#include "assets/asset_id.h"
#include "assets/types/mesh_asset.h"
#include "assets/types/texture_asset.h"


#include <aiko_types.h>
#include <assets/iasset_provider.h>

namespace aiko
{

    class AssetManager : public IAssetProvider
    {
    public:

        virtual const TextureAsset& getTextureAsset(const AssetId& id) override;
        virtual const MeshAsset& getMeshAsset(const AssetId& id) override;
        virtual const ModelAsset& getModelAsset(const AssetId& id) override;

        AssetId registerTexture(std::string_view path);
        AssetId registerMesh(std::string_view path);
        AssetId registerMesh(const MeshAsset& asset);
        AssetId registerModel(std::string_view path);

        bool hasTextureAsset(const AssetId& id) const;
        bool hasMeshAsset(const AssetId& id) const;
        bool hasModelAsset(const AssetId& id) const;

        void clear();
        void unloadTexture(const AssetId& id);
        void unloadMesh(const AssetId& id);
        void unloadModel(const AssetId& id);

    private:

        std::unordered_map<AssetId, string> m_texturePaths;
        std::unordered_map<AssetId, string> m_meshPaths;
        std::unordered_map<AssetId, string> m_modelPaths;

        std::unordered_map<AssetId, TextureAsset> m_textureAssets;
        std::unordered_map<AssetId, MeshAsset> m_meshAssets;
        std::unordered_map<AssetId, ModelAsset> m_modelAssets;

    };

}