#pragma once

#include "assets/types/mesh_asset.h"
#include "assets/types/texture_asset.h"

#include <aiko_types.h>

namespace aiko
{

    class AssetImporter
    {
    public:
        static TextureAsset loadTexture(const string& path);
        static MeshAsset loadMesh(const string& path);
        static ModelAsset loadModel(const string& path);
    };

}