#include "asset_manager.h"

#include "asset_importer.h"

namespace aiko
{

    const TextureAsset& AssetManager::getTextureAsset(const AssetId& id)
    {
        auto it = m_textureAssets.find(id);
        if (it != m_textureAssets.end())
        {
            return it->second;
        }
        auto pathIt = m_texturePaths.find(id);
        AIKO_ASSERT(pathIt != m_texturePaths.end(), "Texture asset id not registered");
        TextureAsset asset = AssetImporter::loadTexture(pathIt->second);
        auto [insertedIt, _] = m_textureAssets.emplace(id, std::move(asset));
        return insertedIt->second;
    }

    const MeshAsset& AssetManager::getMeshAsset(const AssetId& id)
    {
        auto it = m_meshAssets.find(id);
        if (it != m_meshAssets.end())
        {
            return it->second;
        }

        auto pathIt = m_meshPaths.find(id);
        AIKO_ASSERT(pathIt != m_meshPaths.end(), "Texture asset id not registered");

        MeshAsset asset = AssetImporter::loadMesh(pathIt->second);
        auto [insertedIt, _] = m_meshAssets.emplace(id, std::move(asset));
        return insertedIt->second;
    }

    const ModelAsset& AssetManager::getModelAsset(const AssetId& id)
    {
        auto it = m_modelAssets.find(id);
        if (it != m_modelAssets.end())
        {
            return it->second;
        }

        auto pathIt = m_modelPaths.find(id);
        AIKO_ASSERT(pathIt != m_modelPaths.end(), "Mesh asset id not registered");

        ModelAsset asset = AssetImporter::loadModel(pathIt->second);
        auto [insertedIt, _] = m_modelAssets.emplace(id, std::move(asset));
        return insertedIt->second;
    }

    AssetId AssetManager::registerTexture(std::string_view path)
    {
        AssetId id;
        m_texturePaths[id] = string(path);
        return id;
    }

    AssetId AssetManager::registerMesh(std::string_view path)
    {
        AssetId id;
        m_meshPaths[id] = string(path);
        return id;
    }

    AssetId AssetManager::registerMesh(const MeshAsset& asset)
    {
        AssetId id;
        m_meshAssets.emplace(id, asset);
        return id;
    }

    AssetId AssetManager::registerModel(std::string_view path)
    {
        AssetId id;
        m_modelPaths[id] = string(path);
        return id;
    }

    bool AssetManager::hasTextureAsset(const AssetId& id) const
    {
        return m_textureAssets.find(id) != m_textureAssets.end();
    }

    bool AssetManager::hasMeshAsset(const AssetId& id) const
    {
        return m_meshAssets.find(id) != m_meshAssets.end();
    }

    bool AssetManager::hasModelAsset(const AssetId& id) const
    {
        return m_modelAssets.find(id) != m_modelAssets.end();
    }

    void AssetManager::clear()
    {
        m_textureAssets.clear();
        m_meshAssets.clear();
        m_modelAssets.clear();
    }

    void AssetManager::unloadTexture(const AssetId& id)
    {
        AIKO_NOT_IMPLEMENTED;
    }

    void AssetManager::unloadMesh(const AssetId& id)
    {
        AIKO_NOT_IMPLEMENTED;
    }

    void AssetManager::unloadModel(const AssetId& id)
    {
        AIKO_NOT_IMPLEMENTED;
    }
}
