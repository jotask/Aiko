#include "component_window.h"

#include "window.h"

#include <aiko_includes.h>
#include "events/editor_events.h"
#include "core/components_render.h"
#include "aiko_editor.h"
#include "core/imgui_helper.h"

#include <imgui.h>

namespace aiko
{
    namespace editor
    {

        ComponentWindow::ComponentWindow(AikoEditor* editor)
            : Window(editor, "ComponentWindow")
            , selectedGo(nullptr)
        {
            EventSystem::it().bind<HirearchyGameObjectSelectedEvent>(this, &ComponentWindow::onGameObjectSelected);
        }

        void ComponentWindow::render()
        {
            if (ImGui::Begin("Components"))
            {
                if (selectedGo != nullptr)
                {
                    ImGui::Text("Uuid: %s", selectedGo->uuid().get().c_str() );
                    string name = selectedGo->getName();
                    if (imgui::InputText("Name", &name))
                    {
                        selectedGo->setName(name);
                    }
                    ImGui::Spacing();
                    ImGui::Spacing();
                    for (Component* comp : selectedGo->getComponents())
                    {
                        if (ImGui::CollapsingHeader(comp->getName(), ImGuiTreeNodeFlags_DefaultOpen))
                        {
                            ImGui::PushID(comp);
                            if (ImGui::Button("Remove") == true)
                            {
                                selectedGo->removeComponent(comp);
                                ImGui::PopID();
                                continue;
                            }
                            ImGui::PopID();
                            component::drawComponent(comp);
                        }
                    }
                    ImGui::Spacing();
                    ImGui::Spacing();
                    if (ImGui::Button("Add Component", ImVec2(ImGui::GetContentRegionAvail().x, 0)) == true)
                    {
                        ImGui::OpenPopup("Add Component Context");
                    }
                    if (ImGui::BeginPopup("Add Component Context"))
                    {
                        ImGui::SeparatorText("Aquarium");

                        static ImGuiTextFilter filter;
                        ImGui::Text("Filter usage:\n"
                            "  \"\"         display all lines\n"
                            "  \"xxx\"      display lines containing \"xxx\"\n"
                            "  \"xxx,yyy\"  display lines containing \"xxx\" or \"yyy\"\n"
                            "  \"-xxx\"     hide lines containing \"xxx\"");
                        filter.Draw();
                        std::vector<string> components = component::getMissingComponents(selectedGo);
                        for(string component : components)
                        {
                            if (filter.PassFilter(component.c_str()))
                            {
                                if (ImGui::Selectable(component.c_str()) == true)
                                {
                                    component::addComponent(component, selectedGo);
                                }
                            }
                        }
                        ImGui::EndPopup();
                    }
                }
                else
                {
                    ImGui::Text("Nothing selected");
                }
            }
            ImGui::End();

        }

        void ComponentWindow::onGameObjectSelected(HirearchyGameObjectSelectedEvent& envt)
        {
            selectedGo = const_cast<GameObject*>(envt.selected);
        }

    }
}
