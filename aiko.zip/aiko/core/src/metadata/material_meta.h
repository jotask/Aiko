#pragma once

#include "aiko_types.h"
#include "assets/asset_id.h"

namespace aiko
{

    struct MaterialInstance
    {
        AssetId shaderId;
        std::vector<TextureSlotMeta> textures;
        std::vector<UniformValue> uniforms;
    };

}