#pragma once

#include "core/uuid.h"

namespace aiko
{
    using AssetId = uuid::Uuid;
}
