#pragma once

#include <aiko_types.h>

#include "models/compute_buffer.h"
#include "models/compute_shader.h"
#include "models/material.h"
#include "models/mesh.h"
#include "models/texture.h"
#include "models/screen_fbo.h"
#include "types/render_types.h"
#include "renderer/frame_uniforms.h"
#include "types/compute_pass.h"

namespace aiko::renderer
{

    class IRenderDevice
    {
    public:
        IRenderDevice() = default;
        virtual ~IRenderDevice() = default;

        virtual bool init(const DeviceInitDesc& desc) = 0;
        virtual void shutdown() = 0;

        virtual void resize(u32 width, u32 height, bool vsync) = 0;

        virtual void beginFrame() = 0;
        virtual void endFrame() = 0;

        virtual void beginPass(ViewId viewId, const PassDescription& pass, FrameBuffer* frameBuffer = nullptr) = 0;
        virtual void endPass() = 0;

        virtual void present() = 0;

        virtual void renderMesh(ViewId viewId, const mat4 world, const Mesh& mesh, const Material& material) = 0;

        virtual void bindMaterial(const Material& material) = 0;
        virtual void drawMesh(ViewId viewId, const mat4& world, const Mesh& mesh, const Material& material) = 0;

        virtual void presentFrameBufferToScreen(ViewId viewId, const ScreenFbo& fb) = 0;
        virtual void presentTextureToScreen(ViewId viewId, const ScreenFbo& screen, const Texture& texture) = 0;

        virtual void drawMeshInstanced(ViewId viewId, const Mesh& mesh, const Material& material, const void* data, u32 instanceCount, u32 instanceStrideBytes) = 0;

        virtual void bindFrame(ViewId viewId, const FrameData& u) = 0;

        // Compute Shader
        virtual void execute(ViewId viewId, const ComputePass& pass) = 0;
        virtual void requestReadback(const ComputeReadbackRequest& request) = 0;
        virtual bool pollReadback(ComputeReadbackResult& result) = 0;
        virtual void drawMeshInstancedGpu(ViewId viewId, const GpuInstanceDrawDesc& desc) = 0;

    };

}
