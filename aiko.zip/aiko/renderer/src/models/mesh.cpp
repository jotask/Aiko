#include "models/mesh.h"

#include "render_factory.h"

#include <assimp/Importer.hpp>
#include <assimp/scene.h>
#include <assimp/postprocess.h>

#include "constants.h"

namespace aiko
{

    Mesh::Mesh(const MeshAsset& data)
        : Mesh()
    {
        setData(data);
    }

    Mesh::Mesh()
        : backend(nullptr)
    {
        backend=renderer::RendererFactory::createMeshImpl(this);
    }

    void Mesh::refresh()
    {
        backend->refresh();
    }

    uint Mesh::id() const
    {
        return backend->id();
    }

    MeshAsset Mesh::getData() const
    {
        return m_data;
    }

    void Mesh::upload(const MeshAsset& asset)
    {
        setData(asset);
    }

    void Mesh::setData(const MeshAsset& data)
    {
        m_data = data;
        refresh();
    }

    bool Mesh::isValid() const
    {
        return backend->isValid();
    }

    void Mesh::unload()
    {
        backend->unload();
    }

}
