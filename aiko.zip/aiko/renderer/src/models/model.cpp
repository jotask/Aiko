#include "models/model.h"

namespace aiko
{

    Model::Model()
    {

    }

    void Model::upload(const ModelAsset& asset)
    {
        AIKO_NOT_IMPLEMENTED;
    }

    void Model::unload()
    {
        AIKO_NOT_IMPLEMENTED;
    }
}
